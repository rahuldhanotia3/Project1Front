import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { promise } from 'protractor';
import { Observable } from 'rxjs';
import { myconfig } from 'src/ConfigurationFiles/myconfig';
import { ApprovalList } from 'src/Models/approval-list';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  mycon:myconfig;
  constructor(private http : HttpClient) { this.mycon = new myconfig();}

  public getApprovalMasterList(): Observable<any> {
    const url = this.mycon.baseUrl+'/api/ApprovalMasterList/GetAll';
    return this.http.get<any>(url);
  }

  public getModuleNames(): Observable<any> {
    const url = this.mycon.baseUrl+'/api/ModuleName/GetAll';
    return this.http.get<any>(url);
}

public getCategorySubModules(): Observable<any> {
  const url = this.mycon.baseUrl+'/api/CategorySubModule/GetAll';
  return this.http.get<any>(url);
}

public getDepartmentList(): Observable<any> {
  const url = this.mycon.baseUrl+'/api/DepartmentList/GetAll';
  return this.http.get<any>(url);
}

public getDepartmentById(dpid:string): Observable<any> {
  const url = this.mycon.baseUrl+'/api/DepartmentList/GetById?id='+dpid;
  return this.http.get<any>(url);
}

public getUnitModuleList(): Observable<any> {
  const url = this.mycon.baseUrl+'/api/UnitModule/GetAll';
  return this.http.get<any>(url);
}

public getOperatorsModuleList(): Observable<any> {
  const url = this.mycon.baseUrl+'/api/OperatorsModule/GetAll';
  return this.http.get<any>(url);
}

public SubmitData(obj:any): Promise<any> {
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/Save';
  return this.http.post<any>(url,obj).toPromise();
}

public SendMail(): Observable<any> {
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/SendMail';
  return this.http.get<any>(url);
}

public ApprovalListSubmitData(obj:any): Observable<any> {
  const url = this.mycon.baseUrl+'/api/ApprovalList/Save';
  return this.http.post<any>(url,obj);
}

public ApprovalListGetByMasterId(id:number): Promise<any> {
  const url = this.mycon.baseUrl+'/api/ApprovalList/GetByMasterId?id='+id;
  return this.http.get<any>(url).toPromise();
}

public ApprovalMasterGetById(id:number): Observable<any>{
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/GetById?id='+id;
  return this.http.get<any>(url);
}

public UpdateApprovalMasterList(obj:any): Observable<any> {
  const url = this.mycon.baseUrl+'/api/ApprovalMasterList/Update';
  return this.http.post<any>(url,obj);
}

public getApprovalMasterMain(): Observable<any> {
  debugger
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/GetAll';
  return this.http.get<any>(url);
}

public updateApprovalMaster(obj:any): Observable<any> {
  //const url = 'https://uat1.nextgen_api.varuna.net/api/ApprovalMaster/Update';
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/Update';
  return this.http.post<any>(url,obj);
}

public ApprovalMasterByDate(dt:string): Observable<any> {
  console.log("dtdtdt = ",dt);
  //const url = 'https://uat1.nextgen_api.varuna.net/api/ApprovalMaster/GetAllByDate?dt='+dt;
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/GetAllByDate?dt='+dt;
  return this.http.get<any>(url);
}

public GetEmployeeCode(): Observable<any> {  
  //const url = 'https://uat1.nextgen_api.varuna.net/api/ApprovalMaster/GetEmployeeCode';
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/GetEmployeeCode';
  return this.http.get<any>(url);
}

public GetRoleWiseUser(): Observable<any> {  
  //const url = 'https://uat1.nextgen_api.varuna.net/api/ApprovalMaster/GetEmployeeCode';
  const url = this.mycon.baseUrl+'/api/ApprovalMaster/GetRoleWiseUser';
  return this.http.get<any>(url);
}

public DocumentCategoryGetAll(): Observable<any> {  
  const url = this.mycon.baseUrl+'/api/DocumentCategory/GetAll';
  return this.http.get<any>(url);
}

public LogicMasterGetAll(): Observable<any> {  
  const url = this.mycon.baseUrl+'/api/Logic/GetAll';
  return this.http.get<any>(url);
}
}
