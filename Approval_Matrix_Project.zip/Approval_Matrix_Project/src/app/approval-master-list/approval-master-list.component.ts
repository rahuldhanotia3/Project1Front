import { Component, OnInit } from '@angular/core';
import { ProductService } from '../productservice';
import { Product } from '../product';
import { LazyLoadEvent } from 'primeng/api';
import { SelectItem } from 'primeng/api';
import {MessageService} from 'primeng/api';
import { GlobalService } from 'src/Services/global.service';
import {MenuItem} from 'primeng/api';
import { ApprovalMasterList } from 'src/Models/approval-master-list';
import { ApprovalMaster } from 'src/Models/approval-master';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { Session } from 'protractor';
@Component({
  selector: 'app-approval-master-list',
  templateUrl: './approval-master-list.component.html',
  providers: [MessageService],
  styles: [`
      :host ::ng-deep .p-cell-editing {
          padding-top: 0 !important;
          padding-bottom: 0 !important;
      }
  `]
  
})
export class ApprovalMasterListComponent implements OnInit {
  
  first = 0;
  rows = 5;
  searchText="";
  datatable:any;
  UserNameWithId:string="Logged Out";
  // _________________________________________________________________________
  items: MenuItem[];
  mylist = new Array<any>();
  public dtSearch:string;
  approvalList:ApprovalMasterList = new ApprovalMasterList();
  approvalMaster = new Array<any>();
  setId:number;
  products1: Product[];

  products2: Product[];

  statuses: SelectItem[];

  clonedProducts: { [s: string]: Product; } = {};

  constructor(private rt:ActivatedRoute,private route:Router,private service:GlobalService,private productService: ProductService, private messageService: MessageService) {
    debugger
    //this.route.navigate(['create'],{ state: { example: mydata.id ,flag1:'true'}});
    this.UserNameWithId = " ";  
    if(localStorage.getItem("Id") == null)
    {
      this.rt.queryParams.subscribe(params => {
        localStorage.setItem("Id",params['UserId']);
      });
    }
    else
    {
      let name = localStorage.getItem("Id").toString();
      if(name.length >= 8)
      {
        this.rt.queryParams.subscribe(params => {
          if(params['UserId'].toString().length >= 8)
          {
            localStorage.setItem("Id",params['UserId']);
          }
        });
      }
    }
    
      if(localStorage.getItem("Id").toString() == "logout")
      {
        this.route.navigate(['test']);
        localStorage.removeItem("Id");
        
      }
      else
      {
        //this.UserNameWithId = sessionStorage.getItem("Id").toString();
      }

      this.service.getApprovalMasterMain().subscribe(response => {
      this.approvalMaster = response.data;
      
  });
  this.getApprovalMasterMain();
   }


  ngOnInit() {
      
      
      this.productService.getProductsSmall().then(data =>{
          this.products1 = data;
      });
      this.productService.getProductsSmall().then(data =>  {
          this.products2 = data;
      });
        
      this.statuses = [{label: 'In Stock', value: 'INSTOCK'},{label: 'Low Stock', value: 'LOWSTOCK'},{label: 'Out of Stock', value: 'OUTOFSTOCK'}]
      
      this.items = [
          {
              label:'',
              icon:'',
              // items:[
              //     {
              //         label:'New',
              //         icon:'',
              //         items:[
              //         {
              //             label:'Bookmark',
              //             icon:'pi pi-fw pi-bookmark'
              //         },
              //         {
              //             label:'Video',
              //             icon:'pi pi-fw pi-video'
              //         },

              //         ]
              //     },
              //     {
              //         label:'Delete',
              //         icon:'pi pi-fw pi-trash'
              //     },
              //     {
              //         separator:true
              //     },
              //     {
              //         label:'Export',
              //         icon:'pi pi-fw pi-external-link'
              //     }
              // ]
          },
          // {
          //     label:'Edit',
          //     icon:'pi pi-fw pi-pencil',
          //     items:[
          //         {
          //             label:'Left',
          //             icon:'pi pi-fw pi-align-left'
          //         },
          //         {
          //             label:'Right',
          //             icon:'pi pi-fw pi-align-right'
          //         },
          //         {
          //             label:'Center',
          //             icon:'pi pi-fw pi-align-center'
          //         },
          //         {
          //             label:'Justify',
          //             icon:'pi pi-fw pi-align-justify'
          //         },

          //     ]
          // },
          // {
          //     label:'Users',
          //     icon:'pi pi-fw pi-user',
          //     items:[
          //         {
          //             label:'New',
          //             icon:'pi pi-fw pi-user-plus',

          //         },
          //         {
          //             label:'Delete',
          //             icon:'pi pi-fw pi-user-minus',

          //         },
          //         {
          //             label:'Search',
          //             icon:'pi pi-fw pi-users',
          //             items:[
          //             {
          //                 label:'Filter',
          //                 icon:'pi pi-fw pi-filter',
          //                 items:[
          //                     {
          //                         label:'Print',
          //                         icon:'pi pi-fw pi-print'
          //                     }
          //                 ]
          //             },
          //             {
          //                 icon:'pi pi-fw pi-bars',
          //                 label:'List'
          //             }
          //             ]
          //         }
          //     ]
          // },
          // {
          //     label:'Events',
          //     icon:'pi pi-fw pi-calendar',
          //     items:[
          //         {
          //             label:'Edit',
          //             icon:'pi pi-fw pi-pencil',
          //             items:[
          //             {
          //                 label:'Save',
          //                 icon:'pi pi-fw pi-calendar-plus'
          //             },
          //             {
          //                 label:'Delete',
          //                 icon:'pi pi-fw pi-calendar-minus'
          //             },

          //             ]
          //         },
          //         {
          //             label:'Archieve',
          //             icon:'pi pi-fw pi-calendar-times',
          //             items:[
          //             {
          //                 label:'Remove',
          //                 icon:'pi pi-fw pi-calendar-minus'
          //             }
          //             ]
          //         }
          //     ]
          // },
          // {
          //     label:'Quit',
          //     icon:'pi pi-fw pi-power-off'
          // }
      ];
  }

  next() {
    this.first = this.first + this.rows;
}

prev() {
    this.first = this.first - this.rows;
}

reset() {
    this.first = 0;
}

isLastPage(): boolean {
  return this.approvalMaster ? this.first === (this.approvalMaster.length - this.rows): true;
}

isFirstPage(): boolean {
  return this.approvalMaster ? this.first === 0 : true;
}

  onRowEditInit(product: number) {
      //this.clonedProducts[product.id] = {...product};
      //console.log("onRowEditInit");
      
      let mydata = this.approvalMaster.find(acc=>{ 
        return acc.id === product;
     });

      //localStorage.setItem("Id",mydata.id);
      this.route.navigate(['create'],{ state: { example: mydata.id,flag1:'false'}});
      //this.rt.queryParams.subscribe(p=>{console.log(p)})
  }
  public getView(product: number)
  {
    let mydata = this.approvalMaster.find(acc=>{ 
      return acc.id === product;
    });
    this.route.navigate(['create'],{ state: { example: mydata.id ,flag1:'true'}});
  }
  // onRowEditSave(num: number) {
  //     // if (product.price > 0) {
  //     //     delete this.clonedProducts[product.id];
  //     //     this.messageService.add({severity:'success', summary: 'Success', detail:'Product is updated'});
  //     // }  
  //         //this.clonedProducts[product.id];
  //         this.messageService.add({severity:'success', summary: 'Success', detail:'updated'});

  //           let mydata = this.mylist.find(acc=>{ 
  //             return acc.id === num;
  //           });
            
  //           //localStorage.setItem("Id",mydata.id);
  //           //console.log("dt= ",mydata.id);
  //           //console.log("session = ",localStorage.getItem("Id").toString());

  //           this.approvalList.Id = mydata.id;
  //           this.approvalList.Status = mydata.status;
  //           this.approvalList.Department = mydata.department;
  //           this.approvalList.Module = mydata.module;
  //           this.approvalList.ApprovalTypeDescription = mydata.approvalTypeDescription;
  //           this.approvalList.Logic = mydata.logic;
  //           console.log("hh",this.approvalList);
            
  //           this.route.navigate(['/']);
  //           // this.service.UpdateApprovalMasterList(this.approvalList).subscribe(
  //           //   response =>{
  //           //     this.mylist = response;
  //           //   });
  //         console.log("onRowEditSave");
  //         //console.log(this.mylist);
  // }



  onRowEditCancel(product: Product, index: number) {
      this.products2[index] = this.clonedProducts[product.id];
      delete this.products2[product.id];
  }

  public getApprovalMasterMain()
  {
    this.service.getApprovalMasterMain().subscribe(response => {
      this.approvalMaster = response.data;
      //console.log("ll = ",this.approvalMaster);
    });
  }

  public searchByDate()
  {
    //console.log("this.dtSearch = ",this.dtSearch);
    this.service.ApprovalMasterByDate(this.dtSearch).subscribe(
      response=>{this.approvalMaster = response.data;}
    );
  }
}
