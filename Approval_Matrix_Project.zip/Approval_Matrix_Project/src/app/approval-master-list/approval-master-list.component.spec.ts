import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalMasterListComponent } from './approval-master-list.component';

describe('ApprovalMasterListComponent', () => {
  let component: ApprovalMasterListComponent;
  let fixture: ComponentFixture<ApprovalMasterListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalMasterListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalMasterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
