import { DatePipe, DOCUMENT, JsonPipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ApprovalMaster } from 'src/Models/approval-master';
import { DepartmentList } from 'src/Models/department-list';
import { GlobalService } from 'src/Services/global.service';
import {MessageService} from 'primeng/api';
import { UserMaster } from 'src/Models/user-master';
import { ActivatedRoute, Router } from '@angular/router';
import { ApprovalList } from 'src/Models/approval-list';
import { Inject }  from '@angular/core';
import { HtmlParser } from '@angular/compiler';
import { element } from 'protractor';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { relative } from 'path';
@Component({
  selector: 'app-approval-master-home',
  templateUrl: './approval-master-home.component.html',
  providers: [MessageService],
  styleUrls: ['./approval-master-home.component.css']
})
export class ApprovalMasterHomeComponent implements OnInit {
  cities: [];
  tempLength:number = 0;
  flag1:boolean = false; 
  hidelist:boolean = true;
  hidedefault:boolean = true;
  checkApproverList:boolean = false;
  ApprovalArray = [];
  numberofrc:number = 1;
  arrayofcount = [];
  radioChecked:boolean = true;
  hiderolelist:boolean = false;
  DepartmentName:string;
  CategoryName:string;
  ModuleName:string;
  documentCategory:string;
  ModuleStartDt:string;
  LogicName:string;
  UnitName:string;
  OperatorName:string;
  approver1:string;
  approver2:string;
  approver3:string;
  approver4:string;
  RageTo:number;
  RageFrom:number;
  getId:number;
  getViewId:string;
  UserNameWithId:string;
  HideRange:boolean = false;
  approvalCheck :{roleCheck:boolean,logicCheck:boolean,dpt:boolean,catg:boolean,modl:boolean,docCat:boolean,uni:boolean,opert:boolean,empcode:boolean} = {roleCheck:false,logicCheck:false,dpt:false,catg:false,modl:false,docCat:false,uni:false,opert:false,empcode:false};
  
  public arList = new Array<ApprovalList>();
  public dplist = new DepartmentList();
  public ApprovalListArray  = [];
  public moduleName = new Array<any>();
  public DocumentCategory = new Array<any>();
  public CategoryNames = new Array<any>();
  public LogicMaster = new Array<any>();
  public DepartmentList = new Array<DepartmentList>();
  public UnitModuleList = new Array<any>();
  public OperatorsModuleList = new Array<any>();
  public approvalMaster = new ApprovalMaster();
  approvalMasterUpdate = new ApprovalMaster();
  EmployeeCodeList = new Array<any>();
  public btnValue = "Submit";
  public loading:boolean;
  disdepart: boolean = false;
  discat: boolean = false;
  disDocCat:boolean = false;
  dismodule: boolean = false;
  disdt: boolean = false;
  dislogic: boolean = false;
  disunit: boolean = false;
  disoperator: boolean = false;
  disappr1: boolean = false;
  disappr2: boolean = false;
  disappr3: boolean = false;
  disappr4: boolean = false;
  disbtn1:boolean = false;
  disbtn2:boolean = false;
  datePipe : DatePipe;
  disrolewise:boolean = false;
  disewise:boolean = false;
  disAddbtn:boolean = false;
  disRageTo:boolean = false;
  disRageFrom:boolean = false;

  app1:boolean = false;
  constructor(private actroute:Router,private route:ActivatedRoute,private service:GlobalService,private messageservice:MessageService){

    
    try {
      this.getId = this.actroute.getCurrentNavigation().extras.state.example;
      this.getViewId = this.actroute.getCurrentNavigation().extras.state.flag1;
      
      if(this.getId != null)
      {
        this.btnValue = "Update";
      }
    } catch (error)
    {
      
    }
  }
  
  ngOnInit(): void{
    this.loading = true;
    
    this.getModuleNames();
    this.LogicMasterGetAll();
    this.getCategorySubModules(); 
    this.getDepartmentList(); 
    this.getUnitModuleList();
    this.getOperatorsModuleList();
    this.GetAllEmployeeCode();
    this.yesterdayDateFilter();
    this.DocumentCategoryGetAll();
    
  }
  
  yesterdayDateFilter(){        
    //this.ModuleStartDt = new Date('2013-03-10T02:00:00Z').toISOString().split('T')[0];
 }
 onChangeOperator(value: string)
 {  
    if(value == "Between")
    {
      this.HideRange = true;
    }
    else
    {
      this.HideRange = false;
    }
 }
  public getDatafromFields()
  {
    try {
      
      
      this.approvalMaster.ApprovalListArray = [];
      this.approvalMaster.masterType = this.ModuleName;
      this.approvalMaster.masterDiscrition = this.ModuleName;
      this.approvalMaster.baseDocument = this.ModuleName;
      this.approvalMaster.category = this.CategoryName;
      this.approvalMaster.documentCategory = this.documentCategory;
      this.approvalMaster.moduleStartOn = new Date(this.ModuleStartDt);
      this.approvalMaster.department = this.DepartmentName;
      this.approvalMaster.status = "Active";
      this.approvalMaster.logic = this.LogicName;
      this.approvalMaster.calculationBase = this.UnitName;
      this.approvalMaster.operators = this.OperatorName;
      this.approvalMaster.createdBy = localStorage.getItem("Id").toString();
      this.approvalMaster.rageFrom = this.RageFrom;
      this.approvalMaster.rageTo = this.RageTo;
      var temp = 1;
      this.arrayofcount = [];
      //this.numberofrc -= 1;
      while( temp != this.numberofrc)
      {
        this.arrayofcount.push(temp);
        temp += 1;
      }

      for(var i = 0, len = this.arrayofcount.length; i < len; i++) 
      {
            let v = (document.getElementById("input"+this.arrayofcount[i]) as HTMLInputElement).value;
            if(v.trim() != "")
            {
              this.approvalMaster.ApprovalListArray.push(v);
            }
      }
      debugger
       var Ers = (document.getElementById("ewiseid") as HTMLInputElement);
       var Rrs = (document.getElementById("roleid") as HTMLInputElement);
       if(Ers.checked)
       {
        this.approvalMaster.user_Flag = "E";
       }
       else if(Rrs.checked)
       {
        this.approvalMaster.user_Flag = "R";
       }
        // this.arrayofcount.forEach(element =>  {
        //   let v = (document.getElementById("input"+element) as HTMLInputElement).value;
        //     //this.ApprovalArray.push(v);
        //     console.log("getfromfields = "+v);
        //     this.approvalMaster.ApprovalListArray.push(v);
        // });

    } catch (error) {
      this.messageservice.add({severity:'error', summary: 'Error', detail:'Faild To Load Data'});
    }
  }
  addLevels()
  {    
        this.arrayofcount.push(this.numberofrc);
        this.numberofrc += 1;
  }
  Valshow()
  {
    this.ApprovalArray.length = 0;
    for(let o of this.arrayofcount)
    {
      let v = (document.getElementById("input"+o) as HTMLInputElement).value;
      this.ApprovalArray.push(v);
    }
    alert(this.ApprovalArray.toString());
  }
  public OnSubmit()
  {debugger
    try {
      
    if(this.getId != null && this.getViewId == "false")
    {
      this.updateApprovalMaster();
      this.actroute.navigate(['/']);
    }
    else
    {
      let dpt = this.DepartmentList.find(acc=>{ 
        return acc.description === this.DepartmentName;
      })
      this.approvalMaster.department = dpt.pk_deptid;
      this.getDatafromFields();
      this.service.SubmitData(this.approvalMaster).then(response => {
        if(parseInt(response.data) > 0)
        {
          this.messageservice.add({severity:'success', summary: 'Success', detail:'Saved'});
          //this.service.SendMail().subscribe();
          this.actroute.navigate(['/']);
        }
        else
        {
          this.messageservice.add({severity:'error', summary: 'Error', detail:'Please Fill All Fields!'});
        }
      });;
    }
    } catch (error) 
    {
      this.messageservice.add({severity:'error', summary: 'Error', detail:'Faild To Save'});
    }
    this.arrayofcount = [];
    this.numberofrc = 0;
  }

  public getModuleNames()
  {
    this.loading = true;
    this.service.getModuleNames().subscribe(response => {
      this.moduleName = response.data;
      this.approvalCheck.modl = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public DocumentCategoryGetAll()
  {
    this.loading = true;
    this.service.DocumentCategoryGetAll().subscribe(response => {
      this.DocumentCategory = response.data;
      this.approvalCheck.docCat = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public getCategorySubModules()
  {
    this.loading = true;
    this.service.getCategorySubModules().subscribe(response => {
      this.CategoryNames = response.data;
      this.approvalCheck.catg = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public getDepartmentList()
  {
    this.loading = true;
    this.service.getDepartmentList().subscribe(response => {
      this.DepartmentList = response.data;
      this.approvalCheck.dpt = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public getOperatorsModuleList()
  {
    this.loading = true;
    this.service.getOperatorsModuleList().subscribe(response => {
      this.OperatorsModuleList = response.data;
      this.approvalCheck.opert = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public LogicMasterGetAll()
  {
    this.loading = true;
    this.service.LogicMasterGetAll().subscribe(response => {
      this.LogicMaster = response.data;
      this.approvalCheck.logicCheck = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public getUnitModuleList()
  {
    this.loading = true;
    this.service.getUnitModuleList().subscribe(response => {
      this.UnitModuleList = response.data;
      this.approvalCheck.uni = true;
      this.callApprovalAPI(this.checkForApprovalAPICall());
      this.loading = false;
    });
  }

  public onItemChange()
  {
    if(this.getId == null)
    {
      this.numberofrc = 1;
      this.arrayofcount = [];
    }
    //this.GetAllEmployeeCode();
  }

  public getRoleWiseECode()
  {
      this.radioChecked = false;  
      this.EmployeeCodeList = [];
      this.loading = true;
      this.service.GetRoleWiseUser().subscribe(
      response=>{
        this.EmployeeCodeList = response.data;
        this.approvalCheck.roleCheck = true;
        this.approvalCheck.empcode = true;
        this.callApprovalAPI(this.checkForApprovalAPICall());
        this.loading = false;
      });
  }  

  public GetAllEmployeeCode()
  {
    this.radioChecked = true; 
    //var v = (document.getElementById("ewiseid") as HTMLInputElement);
      this.EmployeeCodeList = [];
      this.loading = true;
      this.service.GetEmployeeCode().subscribe(
      response=>{
        this.EmployeeCodeList = response.data;
        this.approvalCheck.empcode = true;
        this.approvalCheck.roleCheck = true;
        this.callApprovalAPI(this.checkForApprovalAPICall());
        this.loading = false;
      });
  }

  checkForApprovalAPICall()
  {
    let temp = true;
    for(let [key,value] of Object.entries(this.approvalCheck))
    {
      if(value == false)
      {
        temp = false;
      }
    }
    return temp;
  }

  callApprovalAPI(arg:boolean)
  {
    
    if(arg)
    {
      this.ApprovalMasterById();
      if(this.getViewId == "true")
      {
        this.setViewData();
      }
    }
  }

  public getDeptId()
  {
    this.getDepartmentList();
    let dpt = this.DepartmentList.find(acc=>{ 
      return acc.description === this.DepartmentName;
    })
  }

  public async setViewData()
  {
    try {
      
      
      if(this.getId != null)
      {
          date: Date;
          this.service.ApprovalMasterGetById(this.getId).subscribe(
          response =>{this.approvalMasterUpdate = response.data;
          this.DepartmentName =this.approvalMasterUpdate.department; 
          this.CategoryName = this.approvalMasterUpdate.category;
          this.documentCategory = this.approvalMasterUpdate.documentCategory;
          this.ModuleName = this.approvalMasterUpdate.baseDocument;
          this.OperatorName = this.approvalMasterUpdate.operators;
          if(this.OperatorName == "Between")
          {
            this.HideRange = true;
          }
          this.LogicName = this.approvalMasterUpdate.logic;
          this.ModuleStartDt = new Date(this.approvalMasterUpdate.moduleStartOn).toISOString().split('T')[0];
          this.UnitName = this.approvalMasterUpdate.calculationBase;
          this.RageFrom = this.approvalMasterUpdate.rageFrom;
          this.RageTo = this.approvalMasterUpdate.rageTo;
        });
  
        await this.service.ApprovalListGetByMasterId(this.getId).then(
          response => { 
            this.ApprovalListArray = response.data;
            this.ApprovalListArray.forEach(t=>{
            });
            this.tempLength = this.ApprovalListArray.length;
            sessionStorage.setItem('len',this.ApprovalListArray.length.toString());
            });
        this.app1 = true;
        this.flag1 = true;
        this.disappr1 = true;
        this.disappr2 = true;
        this.disappr3 = true;
        this.disappr4 = true;
        this.discat = true;
        this.disDocCat = true;
        this.disdepart = true;
        this.disdt = true;
        this.dislogic = true;
        this.dismodule = true;
        this.disoperator = true;
        this.disunit = true;
        this.disbtn1 = true;
        this.disbtn2 = true;
        this.disbtn1 = false;
        this.disbtn2 = false;
        this.btnValue = "Submit";
        this.disbtn1 = true;
        this.disewise = true;
        this.disrolewise = true;
        this.disAddbtn = true;
        this.disRageTo = true;
        this.disRageFrom = true;
    }
    } catch (error) {
      this.messageservice.add({severity:'error', summary: 'Error', detail:'Faild To Load'});
    }
  }

  public async ApprovalMasterById()
  { 
    try {
      
      if(this.getId != null)
    {
    this.ApprovalListArray = [];
    this.numberofrc = 1;
    this.ApprovalArray = [];
    this.arrayofcount = [];
    this.service.ApprovalMasterGetById(this.getId).subscribe(
      response =>{this.approvalMasterUpdate = response.data;
        this.ModuleStartDt = new Date(this.approvalMasterUpdate.moduleStartOn).toISOString().split('T')[0];
        this.DepartmentName =this.approvalMasterUpdate.department; 
        this.CategoryName = this.approvalMasterUpdate.category;
        this.documentCategory = this.approvalMasterUpdate.documentCategory;
        this.ModuleName = this.approvalMasterUpdate.baseDocument;
        this.OperatorName = this.approvalMasterUpdate.operators;
        if(this.OperatorName == "Between")
        {
          this.HideRange = true;
        }
        this.LogicName = this.approvalMasterUpdate.logic;
        this.UnitName = this.approvalMasterUpdate.calculationBase;
        this.RageFrom = this.approvalMasterUpdate.rageFrom;
        this.RageTo = this.approvalMasterUpdate.rageTo;
        sessionStorage.setItem('key',this.approvalMasterUpdate.user_Flag);
      });

     await this.service.ApprovalListGetByMasterId(this.getId).then(
        response => {
          this.ApprovalListArray = response.data;
          this.ApprovalListArray.forEach(t=>{
            //let l = t.userId.split(':');
            //sessionStorage.setItem('tlen',l[1].length);
          });
          this.tempLength = this.ApprovalListArray.length;
          sessionStorage.setItem('len',this.ApprovalListArray.length.toString());
        }
      );

      this.dismodule = true;
      this.disdepart = true;
            if(sessionStorage.getItem('key') == "E")
            {
              //this.disrolewise = true;
              (document.getElementById('roleid') as HTMLInputElement).disabled = true;
              (document.getElementById('ewiseid') as HTMLInputElement).checked = true;
              sessionStorage.removeItem('key'); 
            }
            else if(sessionStorage.getItem('key') == "R")
            {
              //this.disewise = true;
              (document.getElementById('ewiseid') as HTMLInputElement).disabled = true;
              (document.getElementById('roleid') as HTMLInputElement).checked = true;
              sessionStorage.removeItem('key'); 
            }   
        //sessionStorage.removeItem('flag');
        var num = sessionStorage.getItem('len').toString();
        //alert("this.tempLength = "+this.tempLength);
        this.numberofrc = this.tempLength + 1;
        this.flag1 = true;
    }

    } catch (error) {
      this.messageservice.add({severity:'error', summary: 'Error', detail:'Failed To Load'});
    }   
  }
  
  public updateApprovalMaster()
  {
    try{

      this.getDatafromFields();
    this.approvalMaster.Id = this.getId;
    this.service.updateApprovalMaster(this.approvalMaster).subscribe(
      response=>{this.approvalMasterUpdate = response.data;
        if(parseInt(response.data) > 0)
        {
          this.messageservice.add({severity:'success', summary: 'Success', detail:'Updated'});
        }
        else
        {
          this.messageservice.add({severity:'error', summary: 'Error', detail:'Faild To Update'});
        }
      }
    );
    this.btnValue = "Submit";
    }
    catch(error)
    {
      this.messageservice.add({severity:'error', summary: 'Error', detail:'Faild To Update'});
    }
    
  }

}
