import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalMasterHomeComponent } from './approval-master-home.component';

describe('ApprovalMasterHomeComponent', () => {
  let component: ApprovalMasterHomeComponent;
  let fixture: ComponentFixture<ApprovalMasterHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalMasterHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalMasterHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
