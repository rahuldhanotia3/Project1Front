import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApprovalMasterHomeComponent } from './approval-master-home/approval-master-home.component';
import { ApprovalMasterListComponent } from './approval-master-list/approval-master-list.component';
import { TestingComponent } from './testing/testing.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { APP_BASE_HREF } from '@angular/common';

const routes: Routes = [
  {path:'',component:ApprovalMasterListComponent},
  {path:'create',component:ApprovalMasterHomeComponent},
  {path:'test',component:TestingComponent},
  {path:'**',component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  providers: [{
    provide: APP_BASE_HREF,
    useValue: '/'
}],
  exports: [RouterModule]
})
export class AppRoutingModule { }
