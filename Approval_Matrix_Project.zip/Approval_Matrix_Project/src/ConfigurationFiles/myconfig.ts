export class myconfig{
    
    public localUrl = "https://localhost:44301";
    public baseUrl="https://uatnextgenapi.varuna.net";
}