import { ModuleName } from './module-name';

describe('ModuleName', () => {
  it('should create an instance', () => {
    expect(new ModuleName()).toBeTruthy();
  });
});
