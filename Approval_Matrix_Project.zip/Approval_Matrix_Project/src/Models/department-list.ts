export class DepartmentList {
    public pk_deptid:string = "";
    public description:string = "";
}
