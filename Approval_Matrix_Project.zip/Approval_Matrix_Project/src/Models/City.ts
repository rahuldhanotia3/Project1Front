interface City {
    name: string,
    code: string
}