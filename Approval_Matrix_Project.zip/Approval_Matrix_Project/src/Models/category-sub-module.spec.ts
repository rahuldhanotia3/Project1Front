import { CategorySubModule } from './category-sub-module';

describe('CategorySubModule', () => {
  it('should create an instance', () => {
    expect(new CategorySubModule()).toBeTruthy();
  });
});
