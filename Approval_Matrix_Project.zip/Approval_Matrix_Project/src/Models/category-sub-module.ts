export class CategorySubModule {
    public id:number = 0;
    public category:string = "";
}
