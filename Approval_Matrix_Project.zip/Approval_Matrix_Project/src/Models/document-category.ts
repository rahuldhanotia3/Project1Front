export class DocumentCategory {
    public id:Number = 0;
    public documentCategory:string = "";
}
