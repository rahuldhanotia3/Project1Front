import { ApprovalList } from './approval-list';

describe('ApprovalList', () => {
  it('should create an instance', () => {
    expect(new ApprovalList()).toBeTruthy();
  });
});
