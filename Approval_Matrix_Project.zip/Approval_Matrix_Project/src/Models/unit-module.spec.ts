import { UnitModule } from './unit-module';

describe('UnitModule', () => {
  it('should create an instance', () => {
    expect(new UnitModule()).toBeTruthy();
  });
});
