import { OperatorsModule } from './operators-module';

describe('OperatorsModule', () => {
  it('should create an instance', () => {
    expect(new OperatorsModule()).toBeTruthy();
  });
});
