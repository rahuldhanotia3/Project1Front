import { DepartmentList } from './department-list';

describe('DepartmentList', () => {
  it('should create an instance', () => {
    expect(new DepartmentList()).toBeTruthy();
  });
});
