import { ApprovalMasterList } from './approval-master-list';

describe('ApprovalMasterList', () => {
  it('should create an instance', () => {
    expect(new ApprovalMasterList()).toBeTruthy();
  });
});
