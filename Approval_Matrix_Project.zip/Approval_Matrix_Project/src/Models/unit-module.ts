export class UnitModule {
    public id:number = 0;
    public unitModuleName:string = "";
}
