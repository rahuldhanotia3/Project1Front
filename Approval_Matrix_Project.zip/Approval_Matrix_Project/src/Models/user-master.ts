export class UserMaster {
    public userId:string;
    public name:string;
}
