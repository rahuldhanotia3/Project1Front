import { RoleWiseUser } from './role-wise-user';

describe('RoleWiseUser', () => {
  it('should create an instance', () => {
    expect(new RoleWiseUser()).toBeTruthy();
  });
});
