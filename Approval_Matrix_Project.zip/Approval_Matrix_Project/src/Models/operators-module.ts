export class OperatorsModule {
    public id:number = 0;
    public operatorName:string = "";
}
