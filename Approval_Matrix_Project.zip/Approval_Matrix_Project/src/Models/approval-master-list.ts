export class ApprovalMasterList {
    public Id:string;
    public Status:string;
    public Department:string;
    public Module:string;
    public ApprovalTypeDescription:string;
    public Logic:string;
}
