import { DocumentCategory } from './document-category';

describe('DocumentCategory', () => {
  it('should create an instance', () => {
    expect(new DocumentCategory()).toBeTruthy();
  });
});
