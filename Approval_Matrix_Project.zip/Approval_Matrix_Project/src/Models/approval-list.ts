export class ApprovalList {
    public approvalMasterId:number
    public userId:string;
    public user_Flag :string;
}
