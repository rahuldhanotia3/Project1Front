export class ApprovalMaster {
    public Id:number;
    public masterType:string;
    public masterDiscrition:string;
    public baseDocument:string;
    public category:string;
    public documentCategory:string;
    public moduleStartOn:Date;
    public department:string;
    public status:string;
    public logic:string;
    public calculationBase:string;
    public rageFrom:number;
    public rageTo:number;
    public operators:string;
    //public SubCategoryColName:string;
    //public L1Base:string;
    public l1EmployeeCode:string;
    //public L2Base:string;
    public l2EmployeeCode:string;
    //public L3Base:string;
    public l3EmployeeCode:string;
    //public L4Base:string;
    public l4EmployeeCode:string;

    public ApprovalListArray = [];
    
    public user_Flag : string;
    public createdBy : string;
}
