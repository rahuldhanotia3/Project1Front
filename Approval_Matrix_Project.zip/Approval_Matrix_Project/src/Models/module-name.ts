export class ModuleName {
    public id:Number = 0;
    public moduleName:string = "";
}
