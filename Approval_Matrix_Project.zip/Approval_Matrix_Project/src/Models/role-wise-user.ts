export class RoleWiseUser {
    public roleId:number;
    public roleDesc:number;
}
