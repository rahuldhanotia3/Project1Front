import { ApprovalMaster } from './approval-master';

describe('ApprovalMaster', () => {
  it('should create an instance', () => {
    expect(new ApprovalMaster()).toBeTruthy();
  });
});
